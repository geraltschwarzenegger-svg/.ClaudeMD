#!/usr/bin/env python3
"""Структурная проверка навыка geralt-voice.

Запуск из корня репозитория:  python3 geralt-voice/scripts/check.py

Только стандартная библиотека, никаких зависимостей.
Код возврата 0 если всё сошлось, 1 если есть ошибки.

Проверок двенадцать. Они ловят не содержание правил, а расхождения между
файлами: рассинхрон версий, битые ссылки, сбитую нумерацию, дубли.
Ровно тот класс ошибок, который трижды проезжал мимо ручного прогона.
"""

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent      # geralt-voice/
REPO = ROOT.parent                                  # корень репозитория
REFS = ROOT / "references"

errors: list[str] = []
warnings: list[str] = []
facts: list[str] = []


def err(msg: str) -> None:
    errors.append(msg)


def warn(msg: str) -> None:
    warnings.append(msg)


def fact(msg: str) -> None:
    facts.append(msg)


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def ref_files() -> list[Path]:
    return sorted(REFS.glob("*.md"))


def all_md() -> list[Path]:
    return [ROOT / "SKILL.md", ROOT / "CHANGELOG.md"] + ref_files()


# --- 1. Версия совпадает в SKILL.md, CHANGELOG.md и README.md ---------------
def check_version() -> None:
    skill = read(ROOT / "SKILL.md")
    m = re.search(r"\*\*Версия (\d+\.\d+\.\d+)", skill)
    if not m:
        err("SKILL.md: не найдена строка с версией")
        return
    v_skill = m.group(1)

    changelog = read(ROOT / "CHANGELOG.md")
    m = re.search(r"^## (\d+\.\d+\.\d+),", changelog, re.M)
    v_log = m.group(1) if m else None

    readme_path = REPO / "README.md"
    v_readme = None
    if readme_path.exists():
        m = re.search(r"Актуальная версия (\d+\.\d+\.\d+)", read(readme_path))
        v_readme = m.group(1) if m else None

    fact(f"версия: SKILL.md {v_skill}, CHANGELOG {v_log}, README {v_readme}")
    if v_log != v_skill:
        err(f"версии разошлись: SKILL.md {v_skill}, верхняя запись CHANGELOG {v_log}")
    if v_readme and v_readme != v_skill:
        err(f"версии разошлись: SKILL.md {v_skill}, README {v_readme}")


# --- 2. Сквозная нумерация пар в банке примеров -----------------------------
def check_example_numbering() -> None:
    p = REFS / "examples.md"
    nums = [int(n) for n in re.findall(r"^### (\d+)\. ", read(p), re.M)]
    fact(f"пар в банке: {len(nums)}")
    if nums != list(range(1, len(nums) + 1)):
        err(f"examples.md: нумерация пар не сквозная, идёт {nums}")


# --- 3. Все упомянутые файлы существуют -------------------------------------
def check_file_links() -> None:
    known = {p.name for p in ref_files()} | {"SKILL.md", "CHANGELOG.md", "README.md"}
    for p in all_md():
        if p.name == "CHANGELOG.md":
            continue  # журнал законно упоминает удалённые файлы
        for name in set(re.findall(r"`(?:references/)?([a-z0-9-]+\.md)`", read(p))):
            if name not in known:
                err(f"{p.name}: ссылка на несуществующий файл {name}")


# --- 4. Ссылки на номера разделов внутри файла ------------------------------
def check_section_refs() -> None:
    for p in all_md():
        text = read(p)
        have = {int(n) for n in re.findall(r"^## (\d+)\. ", text, re.M)}
        if not have:
            continue
        for n in {int(x) for x in re.findall(r"раздел[а-яё]* (\d+)", text)}:
            if n not in have:
                err(f"{p.name}: ссылка на раздел {n}, которого нет")


# --- 5. Длинное тире ---------------------------------------------------------
def check_em_dash() -> None:
    allowed = ("Длинное тире", "Она ответила —", "убрано 38 длинных тире")
    total = 0
    for p in all_md():
        for i, line in enumerate(read(p).splitlines(), 1):
            if "—" in line and not any(a in line for a in allowed):
                err(f"{p.name}:{i}: длинное тире вне разрешённых мест")
            total += line.count("—")
    fact(f"вхождений длинного тире всего (с разрешёнными): {total}")


# --- 6. Перекрёстные ссылки на пункты чеклиста ------------------------------
def check_checklist_refs() -> None:
    text = read(REFS / "self-check.md")
    have = set(re.findall(r"^([А-Ж]\d+)\.", text, re.M))
    fact(f"пунктов в блоках чеклиста: {len(have)}")
    for ref in set(re.findall(r"\(([А-Ж]\d+)\)", text)):
        if ref not in have:
            err(f"self-check.md: ссылка на пункт {ref}, которого нет")


# --- 7. Оглавление в длинных файлах -----------------------------------------
def check_toc() -> None:
    limit = 200
    for p in ref_files():
        lines = read(p).splitlines()
        if len(lines) > limit and "**Оглавление.**" not in "\n".join(lines[:40]):
            warn(f"{p.name}: {len(lines)} строк и нет оглавления в шапке")


# --- 8. Дубли правил между файлами ------------------------------------------
def check_duplicates() -> None:
    seen: dict[str, str] = {}
    for p in all_md():
        if p.name == "CHANGELOG.md":
            continue
        for raw in read(p).splitlines():
            line = raw.strip()
            if len(line) < 120 or line.startswith(("|", ">", "-", "#")):
                continue
            if line in seen and seen[line] != p.name:
                warn(f"дубль правила: {seen[line]} и {p.name} содержат одну строку")
            seen[line] = p.name


# --- 9. Обязательные разделы SKILL.md и размеры -----------------------------
def check_skill_sections() -> None:
    text = read(ROOT / "SKILL.md")
    required = [
        "## Три работы навыка",
        "## Четыре цикла",
        "## Как это работает, когда он пишет",
        "## Формат ответа Геральту",
        "## Структура",
    ]
    for r in required:
        if r not in text:
            err(f"SKILL.md: пропал обязательный раздел «{r.lstrip('# ')}»")

    n = len(text.splitlines())
    fact(f"SKILL.md: {n} строк (грузится всегда)")
    if n > 180:
        err(f"SKILL.md разросся до {n} строк, потолок 180")
    elif n > 165:
        warn(f"SKILL.md {n} строк, приближается к потолку 180")

    total = sum(len(read(p).splitlines()) for p in all_md())
    fact(f"всего строк в навыке: {total}")

    ex = read(REFS / "examples.md")
    log = len(re.findall(r"^### .*\[лог\]", ex, re.M))
    rule = len(re.findall(r"^### .*\[правило\]", ex, re.M))
    if log + rule:
        fact(f"пары по логам: {log}, по правилам: {rule} "
             f"({round(100 * log / (log + rule))}% живых)")


# --- 10. Маршрутизация: у каждого файла есть адрес в SKILL.md -----------------
def check_routing() -> None:
    skill = read(ROOT / "SKILL.md")
    for p in ref_files():
        if p.name not in skill:
            err(f"{p.name} лежит в references, но адреса в SKILL.md нет: файл никогда не откроется")
    for name in set(re.findall(r"`references/([a-z0-9-]+\.md)`", skill)):
        if not (REFS / name).exists():
            err(f"SKILL.md шлёт в references/{name}, а файла нет")


# --- 11. Оглавление не разошлось с числом разделов ---------------------------
def check_toc_drift() -> None:
    for p in ref_files():
        text = read(p)
        m = re.search(r"\*\*Оглавление\.\*\*(.+)", text)
        if not m:
            continue
        listed = len(re.findall(r"\d+\.\s", m.group(1)))
        actual = len(re.findall(r"^## (\d+)\. ", text, re.M))
        if actual and listed and listed != actual:
            err(f"{p.name}: в оглавлении {listed} разделов, в файле {actual}")


# --- 12. Дубли номеров разделов внутри файла ---------------------------------
def check_section_dupes() -> None:
    for p in all_md():
        nums = re.findall(r"^## (\d+)\. ", read(p), re.M)
        dupes = {n for n in nums if nums.count(n) > 1}
        if dupes:
            err(f"{p.name}: номер раздела повторяется: {sorted(dupes)}")


def main() -> int:
    for check in (
        check_version,
        check_example_numbering,
        check_file_links,
        check_section_refs,
        check_em_dash,
        check_checklist_refs,
        check_toc,
        check_duplicates,
        check_skill_sections,
        check_routing,
        check_toc_drift,
        check_section_dupes,
    ):
        check()

    print("ФАКТЫ")
    for f in facts:
        print(f"  {f}")

    if warnings:
        print("\nПРЕДУПРЕЖДЕНИЯ")
        for w in warnings:
            print(f"  {w}")

    if errors:
        print("\nОШИБКИ")
        for e in errors:
            print(f"  {e}")
        print(f"\nПРОВАЛ: ошибок {len(errors)}, предупреждений {len(warnings)}")
        return 1

    print(f"\nВСЁ СОШЛОСЬ. Предупреждений {len(warnings)}, ошибок нет")
    return 0


if __name__ == "__main__":
    sys.exit(main())
